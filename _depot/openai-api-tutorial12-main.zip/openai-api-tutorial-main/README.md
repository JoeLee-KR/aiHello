# 실전 12가지 프로젝트로 배우는 OpenAI API, 랭체인 완벽 활용법
`실전 12가지 프로젝트로 배우는 OpenAI API, 랭체인 완벽 활용법` 교재의 깃허브입니다.  


![cover](https://github.com/user-attachments/assets/ba05ccf0-5779-4cbc-b304-5bda9c89dfaa)



## 문의사항 (Inquiries)

궁금한 사항이 있으면 이슈 또는 이메일 부탁드립니다.

## 저자 (Authors)

김준성 / (wnstlddl@gmail.com)  : AI 연구원  
브라이스유 / (nlp.consulting777@gmail.com) :  딥 러닝 자연어 처리 연구원  
안상준 / (dailybugle@naver.com) : AI 분야 강사 및 겸임 교수


