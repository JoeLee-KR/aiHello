import streamlit as st

st.title("나의 첫 번째 Streamlit 앱")

st.header("Streamlit에 오신 것을 환영합니다")
st.subheader("웹 앱을 만들기 위한 강력하고 사용하기 쉬운 라이브러리")

st.text("이것은 일반 텍스트입니다.")

st.write("write() 함수를 사용하여 텍스트, 데이터 또는 플롯을 표시할 수도 있습니다.")